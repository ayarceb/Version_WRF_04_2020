Tools distributed with LOTOS-EUROS open source version.

meteo/
  Scripts to create meteorological input from ECMWF data.

